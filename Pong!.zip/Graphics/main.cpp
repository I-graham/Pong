#include <SFML/Graphics.hpp>
#include <iostream>

int main() {
	int scores = 0;
	int loss = 0;
	bool hit = false;
	float speed = 0;
	int dir = 0;
	float enemyspeed = 0;
	int enemydir = 0;
	bool up = true;
	sf::Clock clock;
	sf::CircleShape scoreM(10, 4);
	sf::CircleShape lossM(10, 4);
	scoreM.setPosition(sf::Vector2f(0.f, 0.f));
	lossM.setPosition(sf::Vector2f(0.f, 825.f));
	sf::RenderWindow window(sf::VideoMode(1400, 850), "Pong!");
	window.setVerticalSyncEnabled(true);
	window.clear();
	sf::RectangleShape enemy(sf::Vector2f(80.f, 20.f));
	enemy.setPosition(sf::Vector2f(1340.f, 780.f));
	sf::RectangleShape shape(sf::Vector2f(80.f, 20.f));
	sf::RectangleShape ball(sf::Vector2f(15.f, 15.f));
	shape.setFillColor(sf::Color::White);
	shape.setOutlineThickness(-5.f);
	shape.setOutlineColor(sf::Color(0, 0, 0));
	enemy.setOutlineThickness(-5.f);
	enemy.setOutlineColor(sf::Color(0, 0, 0));
	ball.setPosition(sf::Vector2f(700.f, 800.f));
	shape.setPosition(sf::Vector2f(0.f, 25.f));
	sf::Clock moving;
	sf::Clock enemyc;
	sf::RectangleShape leftBorder(sf::Vector2f(30.f, 850.f));
	leftBorder.setPosition(sf::Vector2f(-30.f, 0.f));
	sf::RectangleShape rightBorder(sf::Vector2f(30.f, 850.f));
	rightBorder.setPosition(sf::Vector2f(1400.f, 0.f));
	sf::RectangleShape defend(sf::Vector2f(1400.f, 5.f));
	sf::RectangleShape goal(sf::Vector2f(1400.f, 5.f));
	goal.setPosition(sf::Vector2f(0.f, 825.f));
	sf::RectangleShape screen(sf::Vector2f(1400.f, 850.f));

	while (window.isOpen())
	{
		if (clock.getElapsedTime().asMicroseconds() >= 1500) {
			clock.restart();
			window.clear();
			sf::Event event;
			while (window.pollEvent(event))
			{
				switch (event.type) {
				case sf::Event::Closed:
					window.close();
					break;
				case sf::Event::KeyPressed:
					switch (event.key.code) {
					case sf::Keyboard::Left:
						moving.restart();
						dir = -1;
						break;
					case sf::Keyboard::Right:
						moving.restart();
						dir = 1;
						break;
					}
					break;
				case sf::Keyboard::Space:
					if (!ball.getGlobalBounds().intersects(screen.getGlobalBounds())) {
						ball.setPosition(sf::Vector2f(700.f, 700.f));
						hit = false;
						up = true;
					}
					break;
				case sf::Event::KeyReleased:
					switch (event.key.code) {
					case sf::Keyboard::Left:
						dir = 0;
						moving.restart();
						break;
					case sf::Keyboard::Right:
						dir = 0;
						moving.restart();
						break;
					}
				}
			}

			if (sf::Keyboard::isKeyPressed(sf::Keyboard::Left) && shape.getPosition().x > 0)
				shape.move(-15.f, 0.f);
			if (sf::Keyboard::isKeyPressed(sf::Keyboard::Right) && shape.getPosition().x < 1320)
				shape.move(15.f, 0.f);

			if (ball.getGlobalBounds().intersects(shape.getGlobalBounds())) {
				up = !up;
				hit = false;
				speed = (float)(moving.getElapsedTime().asSeconds() * dir);
			}

			if (ball.getPosition().x > (enemy.getPosition().x + 10.f)) {
				enemy.move(6.f, 0.f);
				if (enemydir != 1) {
					enemydir = 1;
					enemyc.restart();
				}
			}

			else if (ball.getPosition().x < (enemy.getPosition().x + 10.f)) {
				enemy.move(-6.f, 0.f);
				if (enemydir != -1) {
					enemydir = -1;
					enemyc.restart();
				}
			}
			else {
				enemydir = 0;
				enemyc.restart();
			}
			if (ball.getGlobalBounds().intersects(enemy.getGlobalBounds())) {
				up = !up;
				hit = false;
				enemyspeed = (float)(enemyc.getElapsedTime().asSeconds());
			}

			if (ball.getGlobalBounds().intersects(leftBorder.getGlobalBounds()) || ball.getGlobalBounds().intersects(rightBorder.getGlobalBounds()))
				hit = true;



			if (up) {
				if(!hit)
					ball.move(enemyspeed * 18, -4.f);
				else
					ball.move(-1 * enemyspeed * 18, -4.f);
			}
			else if (!up) {
				if (!hit)
					ball.move(speed * 30, 4.f);
				else
					ball.move(-1 * speed * 30, 4.f);
			}

			if (ball.getGlobalBounds().intersects(defend.getGlobalBounds())) {
				loss += 1;
				ball.setPosition(sf::Vector2f(700.f, 700.f));
				hit = false;
				up = true;
			}
			else if (ball.getGlobalBounds().intersects(goal.getGlobalBounds())) {
				scores += 1;
				ball.setPosition(sf::Vector2f(700.f, 700.f));
				hit = false;
				up = true;
			}

			for (int s = 0; s < scores; s++) {
				window.draw(scoreM);
				scoreM.move(20.f, 0.f);
			}

			for (int l = 0; l < loss; l++) {
				window.draw(lossM);
				lossM.move(20.f, 0.f);
			}

			window.draw(shape);
			window.draw(ball);
			window.draw(enemy);
			window.display();
			scoreM.setPosition(sf::Vector2f(0.f, 0.f));
			lossM.setPosition(sf::Vector2f(0.f, 825.f));
		}
	}
	return 0;
}
